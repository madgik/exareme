This directory contains "library" functions for PyPy
