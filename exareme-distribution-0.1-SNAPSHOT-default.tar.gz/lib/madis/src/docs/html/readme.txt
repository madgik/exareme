This directory contains Madis' html documentation. This directory isn't
tracked by mercurial